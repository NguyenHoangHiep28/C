#include<stdio.h>
int main()
{
int a, b, c, sum;
printf("\n Enter any three numbers: \n");
scanf("%d %d %d", &a, &b, &c);
sum = a + b + c;
printf("\n Sum = %d", sum);
return 0;
}
