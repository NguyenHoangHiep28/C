#include <stdio.h>
	main (){
		signed char gender;
		gender = 'M';
		unsigned int mark;
		mark = 60000;
		long int money;
		money = 1000000;
		printf("Congratulation! You just have %d dollar\n", money);
		double area;
		area = 23.7171637483;
	
		float height;
		height = 25.551344;
		
		
		
		
		
	}
